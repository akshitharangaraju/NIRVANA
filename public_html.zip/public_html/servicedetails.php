<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize form inputs from service provider's entry form
    $name = htmlspecialchars($_POST['name']);
    $mobile = htmlspecialchars($_POST['mobile']);
    $shop_name = htmlspecialchars($_POST['shop_name']);
    $address = htmlspecialchars($_POST['address']);

    // Log received values for debugging
    error_log("Received values - Name: $name, Mobile: $mobile, Shop Name: $shop_name, Address: $address");

    // Validation (basic example)
    $errors = [];
    if (empty($name)) {
        $errors[] = "Name is required.";
    }
    if (empty($mobile) || !preg_match("/^[0-9]{10}$/", $mobile)) {
        $errors[] = "A valid 10-digit mobile number is required.";
    }
    if (empty($shop_name)) {
        $errors[] = "Shop name is required.";
    }
    if (empty($address)) {
        $errors[] = "Address is required.";
    }

    // If there are errors, display them
    if (!empty($errors)) {
        echo "<h1>Error:</h1>";
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul>";
    } else {
        // Database connection settings
        $servername = "localhost"; // Your database server name
        $username = "root"; // Your database username
        $password = "0406"; // Your database password
        $dbname = "db"; // Your database name

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname, 3306);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO serviceprovider (name, mobile, shop_name, address) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $mobile, $shop_name, $address);

        // Execute the query
        if ($stmt->execute()) {
            echo '<script>
            alert("Details submitted successfully");
            setTimeout(function() {
                window.location.href = "serviceprovider.html";
            }, 1000);
          </script>';
} else {
    echo "<h1>Error:</h1>";
    echo "<p>There was an error saving your details. Please try again later.</p>";
}

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    }
}
?>
