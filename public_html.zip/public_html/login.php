<?php
// Assuming your database connection is established somewhere
// Define your database connection variables here
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "0406";
$dbname = "db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, 3306);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize user inputs
function sanitizeInput($input) {
    // You can add more sanitization methods as needed
    return htmlspecialchars(stripslashes(trim($input)));
}

// User login function for userentry table
function loginUser_userentry($username, $password, $conn) {
    $username = sanitizeInput($username);
    $password = sanitizeInput($password);
    
    // Query to check if user exists and password matches
    $sql = "SELECT * FROM userentry WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // User exists, login successful
        return true;
    } else {
        // User does not exist or password is incorrect
        return false;
    }
}

// Create account function for userentry table
function createAccount_userentry($username, $password, $conn) {
    $username = sanitizeInput($username);
    $password = sanitizeInput($password);
    
    // Check if username already exists
    $checkUserQuery = "SELECT * FROM userentry WHERE username='$username'";
    $checkUserResult = $conn->query($checkUserQuery);
    
    if ($checkUserResult->num_rows > 0) {
        // Username already exists
        return false;
    } else {
        // Insert new user into the database
        $insertUserQuery = "INSERT INTO userentry (username, password) VALUES ('$username', '$password')";
        if ($conn->query($insertUserQuery) === TRUE) {
            // New user created successfully
            return true;
        } else {
            // Error creating user
            return false;
        }
    }
}

// Reset password function for userentry table
function resetPassword_userentry($username, $password, $conn) {
    $username = sanitizeInput($username);
    $password = sanitizeInput($password);
    
    // Update password in the database
    $updatePasswordQuery = "UPDATE userentry SET password='$password' WHERE username='$username'";
    if ($conn->query($updatePasswordQuery) === TRUE) {
        // Password reset successful
        return true;
    } else {
        // Error resetting password
        return false;
    }
}

// User login function for service table
function loginUser_service($username, $password, $conn) {
    $username = sanitizeInput($username);
    $password = sanitizeInput($password);
    
    // Query to check if user exists and password matches
    $sql = "SELECT * FROM service WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // User exists, login successful
        return true;
    } else {
        // User does not exist or password is incorrect
        return false;
    }
}

// Create account function for service table
function createAccount_service($username, $password, $conn) {
    $username = sanitizeInput($username);
    $password = sanitizeInput($password);
    
    // Check if username already exists
    $checkUserQuery = "SELECT * FROM service WHERE username='$username'";
    $checkUserResult = $conn->query($checkUserQuery);
    
    if ($checkUserResult->num_rows > 0) {
        // Username already exists
        return false;
    } else {
        // Insert new user into the database
        $insertUserQuery = "INSERT INTO service (username, password) VALUES ('$username', '$password')";
        if ($conn->query($insertUserQuery) === TRUE) {
            // New user created successfully
            return true;
        } else {
            // Error creating user
            return false;
        }
    }
}

// Reset password function for service table
function resetPassword_service($username, $password, $conn) {
    $username = sanitizeInput($username);
    $password = sanitizeInput($password);
    
    // Update password in the database
    $updatePasswordQuery = "UPDATE service SET password='$password' WHERE username='$username'";
    if ($conn->query($updatePasswordQuery) === TRUE) {
        // Password reset successful
        return true;
    } else {
        // Error resetting password
        return false;
    }
}

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if action is login for userentry table
    if ($_POST["action"] == "login_userentry") {
        $username = $_POST["username"];
        $password = $_POST["password"];
        
        // Call login function for userentry table
        $loginResult = loginUser_userentry($username, $password, $conn);
        if ($loginResult) {
            // Login successful
            header("Location:userlocation.html");

        } else {
            // Login failed
            echo "Invalid username or password!";
        }
    }
    
    // Check if action is register for userentry table
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["action"]) && $_POST["action"] == "register_userentry") {
        $username = $_POST["username"];
        $password = $_POST["password"];
        
        // Call create account function for userentry table
        $createAccountResult = createAccount_userentry($username, $password, $conn);
        if ($createAccountResult) {
            // Account created successfully
            echo '<script>
                    alert("Account created successfully!");
                    setTimeout(function() {
                        window.location.href = "login.html"; // Replace with your desired URL
                    }, 1000);
                  </script>';
        } else {
            // Failed to create account
            echo '<script>
                    alert("Username already exists!");
                    setTimeout(function() {
                        window.location.href = "signup.html"; // Replace with your desired URL
                    }, 1000);
                  </script>';
        }
    }
    
    
    // Check if action is reset password for userentry table
    if ($_POST["action"] == "reset_password_userentry") {
        $username = $_POST["username"];
        $password = $_POST["password"];
        
        // Call reset password function for userentry table
        $resetPasswordResult = resetPassword_userentry($username, $password, $conn);
        if ($resetPasswordResult) {
            // Password reset successful
            echo '<script>
                    alert("password reset successfull!");
                    setTimeout(function() {
                        window.location.href = "login.html"; // Replace with your desired URL
                    }, 1000);
                  </script>';
        } else {
            // Failed to reset password
            echo '<script>
                    alert("unsuccessful");
                    setTimeout(function() {
                        window.location.href = "forgot_password.html"; // Replace with your desired URL
                    }, 1000);
                  </script>';
        }
    }
    
    // Check if action is login for service table
    if ($_POST["action"] == "login_service") {
        $username = $_POST["username"];
        $password = $_POST["password"];
        
        // Call login function for service table
        $loginResult = loginUser_service($username, $password, $conn);
        if ($loginResult) {
            // Login successful
            header("Location:serviceprovider.html");
        } else {
            // Login failed
            echo "Invalid username or password!";
        }
    }
    
    // Check if action is register for service table
    if ($_POST["action"] == "register_serviceproviderentry") {
        $username = $_POST["username"];
        $password = $_POST["password"];
        
        // Call create account function for service table
        $createAccountResult = createAccount_service($username, $password, $conn);
        if ($createAccountResult) {
            // Account created successfully
            echo '<script>
                    alert("Account created successfully!");
                    setTimeout(function() {
                        window.location.href = "slogin.html"; // Replace with your desired URL
                    }, 1000);
                  </script>';
        } else {
            // Failed to create account
            echo '<script>
                    alert("Username already exists!");
                    setTimeout(function() {
                        window.location.href = "ssignup.html"; // Replace with your desired URL
                    }, 1000);
                  </script>';
        }
    }
    
    
    // Check if action is reset password for service table
    if ($_POST["action"] == "reset_password_serviceproviderentry") {
        $username = $_POST["username"];
        $password = $_POST["password"];
        
        // Call reset password function for service table
        $resetPasswordResult = resetPassword_service($username, $password, $conn);
        if ($resetPasswordResult) {
            // Password reset successful
            echo '<script>
                    alert("password reset successfull!");
                    setTimeout(function() {
                        window.location.href = "slogin.html"; // Replace with your desired URL
                    }, 1000);
                  </script>';
        } else {
            // Failed to reset password
            echo '<script>
                    alert("unsuccessful");
                    setTimeout(function() {
                        window.location.href = "sforgot_password.html"; // Replace with your desired URL
                    }, 1000);
                  </script>';
        }
    }
}