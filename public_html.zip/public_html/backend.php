<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize user location from the HTML form
    $userLocation = htmlspecialchars($_POST['user_location']);
    //echo "$userLocation <br>";

    // Extract meaningful substrings from the location
    $locationParts = explode(',', $userLocation); // Split by comma
    $locationParts = array_map('trim', $locationParts); // Trim whitespace
    // foreach($locationParts as $x){
    //     echo "$x <br>";}
        
    
    // Database connection settings
    $servername = "localhost";
    $username = "root";
    $password = "0406";
    $dbname = "db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare the SQL query to select service providers whose addresses contain any of the extracted substrings
    $sql = "SELECT * FROM serviceprovider WHERE ";
    $conditions = [];
    foreach ($locationParts as $part) {
        $conditions[] = "address LIKE ?";
    }
    $sql .= implode(" OR ", $conditions);

    // Prepare the statement
    $stmt = $conn->prepare($sql);

    // Dynamically bind parameters with '%' wildcards
    $searchTerms = array_map(function($part) { return "%$part%"; }, $locationParts);
    $types = str_repeat('s', count($searchTerms));
    $stmt->bind_param($types, ...$searchTerms);

    // Execute the query
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if any matching service provider is found
    if ($result->num_rows > 0) {
        // Display service provider details for each matching address
        while ($row = $result->fetch_assoc()) {
            echo "<h2>Service Provider Details:</h2>";
            echo "<p>Name: " . $row['name'] . "</p>";
            echo "<p>Mobile: " . $row['mobile'] . "</p>";
            echo "<p>Shop Name: " . $row['shop_name'] . "</p>";
            echo "<p>Address: " . $row['address'] . "</p>";
            echo "<hr>"; // Add a horizontal line between each service provider
        }
    } else {
        // If no matching service provider is found, display a message
        echo "No service providers found near the user's location.";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
