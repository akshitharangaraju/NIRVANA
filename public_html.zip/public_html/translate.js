const translations = {
    en: {
        ufp: "User Forgot Password",
        heading: "BREAKDOWN BUDDY",
        userButton: "User",
        serviceButton: "Service Provider",
        userLoginHeading: "User Login",
        serviceProviderLoginHeading: "Service Provider Login",
        username: "Username",
        password: "Password",
        forgotPassword: "Forgot password?",
        loginButton: "Login",
        noaccount: "Don't have an account?",
        signUp: "Sign Up",
        resetPasswordInfo: "You can reset your password here.",
        resetButton: "Reset Password",
        heading1: "Sign up",
        username1: "Enter your Username",
        password1: "Enter your Password",
        confirm_password1: "Confirm your password",
        signUpButton1: "Register",
        heading2: "Find Service Providers Near You",
        fetchingLocation2: "Fetching location...",
        getServiceProviders2: "Get Service Providers",
        location: "Location",
        geolocationNotSupported: "Geolocation is not supported by this browser.",
        latitude: "Latitude",
        longitude: "Longitude",
        locationDetailsUnavailable: "Unable to retrieve location details.",
        errorRetrievingLocation: "Error retrieving location details:",
        permissionDenied: "User denied the request for Geolocation.",
        locationUnavailable: "Location information is unavailable.",
        locationRequestTimedOut: "The request to get user location timed out.",
        unknownError: "An unknown error occurred.",
        name3: "Name:",
        mobileNo3: "Mobile no:",
        shopName3: "Shop name:",
        address3: "Address:",
        getLocation3: "Get My Location",
        submit3: "Submit",
        invalidMobile: "Please enter a valid 10-digit mobile number.",
        eyu:"Username:",
        p1:"Enter Password:",
        c1:"Re-enter Password:"
    },
    hi: {
        ufp: "उपयोगकर्ता भूल गए?",
        heading: "ब्रेकडाउन बडी",
        userButton: "उपयोगकर्ता",
        serviceButton: "सेवा प्रदाता",
        userLoginHeading: "उपयोगकर्ता लॉगिन",
        serviceProviderLoginHeading: "सेवा प्रदाता लॉगिन",
        username: "उपयोगकर्ता नाम",
        password: "पासवर्ड",
        forgotPassword: "पासवर्ड भूल गए?",
        loginButton: "लॉगिन",
        noaccount: "खाता नहीं है?",
        signUp: "साइन अप करें",
        resetPasswordInfo: "आप यहां अपना पासवर्ड रीसेट कर सकते हैं।",
        resetButton: "पासवर्ड रीसेट करें",
        heading1: "साइन अप करें",
        username1: "अपना उपयोगकर्ता नाम दर्ज करें",
        password1: "अपना पासवर्ड दर्ज करें",
        confirm_password1: "अपना पासवर्ड पुष्टि करें",
        signUpButton1: "रजिस्टर",
        heading2: "अपने पास सेवा प्रदाताओं को खोजें",
        fetchingLocation2: "स्थान प्राप्त किया जा रहा है...",
        getServiceProviders2: "सेवा प्रदाताओं को प्राप्त करें",
        location: "स्थान",
        geolocationNotSupported: "इस ब्राउज़र द्वारा भूमिका निर्धारण समर्थित नहीं है।",
        latitude: "अक्षांश",
        longitude: "देशांतर",
        locationDetailsUnavailable: "स्थान विवरण प्राप्त करने में असमर्थ।",
        errorRetrievingLocation: "स्थान विवरण प्राप्त करने में त्रुटि:",
        permissionDenied: "उपयोगकर्ता ने भूमिका निर्धारण के लिए अनुमति नहीं दी।",
        locationUnavailable: "स्थान सूचना अनुपलब्ध है।",
        locationRequestTimedOut: "उपयोगकर्ता स्थान प्राप्ति के लिए अनुरोध का समय समाप्त हो गया।",
        unknownError: "एक अज्ञात त्रुटि हुई।",
        name3: "नाम:",
        mobileNo3: "मोबाइल नंबर:",
        shopName3: "दुकान का नाम:",
        address3: "पता:",
        getLocation3: "मेरा स्थान प्राप्त करें",
        submit3: "प्रस्तुत करें",
        invalidMobile: "कृपया एक वैध 10-अंकों का मोबाइल नंबर दर्ज करें।",
        eyu:"उपयोगकर्ता नाम:",
        p1:"पासवर्ड दर्ज करें:",
        c1:"पासवर्ड फिर से दर्ज करें:"

    },
    te: {
        ufp: "వినియోగదారు పాస్వర్డ్ మర్చిపోయారా?",
        heading: "బ్రేక్‌డౌన్ బడీ",
        userButton: "వినియోగదారు",
        serviceButton: "సేవా సరఫరాదారు",
        userLoginHeading: "వినియోగదారు లాగిన్",
        serviceProviderLoginHeading: "సేవా సరఫరాదారు లాగిన్",
        username: "వినియోగదారు పేరు",
        password: "పాస్వర్డ్",
        forgotPassword: "పాస్వర్డ్ మర్చిపోయారా?",
        loginButton: "లాగిన్",
        noaccount: "ఖాతా లేదా?",
        signUp: "సైన్ అప్ చేయండి",
        resetPasswordInfo: "మీ పాస్వర్డ్ ఇక్కడ రీసెట్ చేయవచ్చు.",
        resetButton: "పాస్వర్డ్ రీసెట్ చేయండి",
        heading1: "నమోదు చేయండి",
        username1: "మీ వినియోగదారు పేరు నమోదు చేయండి",
        password1: "మీ పాస్వర్డ్ నమోదు చేయండి",
        confirm_password1: "మీ పాస్వర్డ్ నమోదు మళ్ళీ నమోదు చేయండి",
        signUpButton1: "నమోదు చేయండి",
        heading2: "మీ సమీప సేవా ప్రోవైడర్లను కనుగొనండి",
        fetchingLocation2: "స్థానాన్ని తీసుకువస్తోంది...",
        getServiceProviders2: "సేవా ప్రోవైడర్లను పొందండి",
        location: "స్థానం",
        geolocationNotSupported: "ఈ బ్రౌజర్‌లో భూగర్భావస్థ మద్దతు లేదు.",
        latitude: "అక్షాంశం",
        longitude: "దేశాంతరం",
        locationDetailsUnavailable: "స్థాన వివరాలను పొందడం సాధ్యపడదు.",
        errorRetrievingLocation: "స్థాన వివరాలు పొందడంలో లోపం:",
        permissionDenied: "వినియోగదారు భూగర్భావస్థ కోసం అనుమతించలేదు.",
        locationUnavailable: "స్థాన సమాచారం లేదు.",
        locationRequestTimedOut: "వినియోగదారు స్థాన అనురోధం టైమ్ ఔట్ అయింది.",
        unknownError: "తెలియని లోపం జరిగింది.",
        name3: "పేరు:",
        mobileNo3: "మొబైల్ నంబర్:",
        shopName3: "షాప్ పేరు:",
        address3: "చిరునామా:",
        getLocation3: "నా స్థానం పొందండి",
        submit3: "సమర్పించు",
        invalidMobile: "దయచేసి ఒక చెందిన మొబైల్ నంబర్ను నమోదు చేయండి (10 అంకెలు).",
        eyu: "వినియోగదారు పేరు:",
        p1:"పాస్వర్డ్‌ను నమోదు చేయండి:",
        c1:"పాస్వర్డ్‌ను మళ్లీ నమోదు చేయండి:"

    }
};


function applySavedLanguage() {
    var language = localStorage.getItem('selectedLanguage') || 'en';
    console.log('Selected language:', language);
    document.documentElement.lang = language;
}

function translatePage() {
    var language = localStorage.getItem('selectedLanguage') || 'en';
    console.log('Translating page to language:', language);
    var elements = document.querySelectorAll('[data-translate]');
    elements.forEach(function(element) {
        var key = element.getAttribute('data-translate');
        if (translations[language] && translations[language][key] !== undefined) {
            element.textContent = translations[language][key];
        } else {
            console.warn(`Translation not found for key "${key}" in language "${language}".`);
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    applySavedLanguage();
    translatePage();
});

